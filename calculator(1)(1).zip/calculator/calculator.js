window.onload= function() {
  const addActivityBtn = document.getElementById('addActivity');
  var row = document.getElementsByClassName('activities');
  const weightBtn = document.getElementById('weightBtn');
  const meanBtn = document.getElementById('meanBtn');
  
  addActivityBtn.addEventListener('click', function() {
    const index = document.getElementById('tbody').children.length;
    const tr = document.createElement('tr');
    tr.classList.add('activities');
    tr.innerHTML = `
      <td>Activity${index}</td>
      <td>A${index}</td>
      <td>
        <input id="weight" type="number">
      </td>
      <td>
        <div class="grade-group">
          <input id="grade1" type="number"><span class="slash">/</span><input id="grade2" type="number">
        </div>
      </td>
      <td id="percent"></td>
      `
    document.getElementById('tbody').appendChild(tr)
    row = document.getElementsByClassName('activities');
    computedPercent();
  })

  weightBtn.addEventListener('click', function() {
    const result = document.getElementById('computedResult');
    computedResult.innerHTML = ''
    const isValidInput = validateInputValue();
    if (!isValidInput) return;

    // compute Weighted grades
    let value = 0;
    let count = 0;
    const list = document.getElementsByClassName('activities');
    Array.prototype.forEach.call(list, function(e) {
      const grade1 = e.querySelector('#grade1');
      const grade2 = e.querySelector('#grade2');
      const weight = e.querySelector('#weight');
      const val = (parseInt(grade1.value)/parseInt(grade2.value))*parseInt(weight.value);
      value = value + val;
      count = count + parseInt(weight.value);
    })
    computedResult.innerHTML = value/count;
  })

  meanBtn.addEventListener('click', function() {
    const result = document.getElementById('computedResult');
    computedResult.innerHTML = ''
    const isValidInput = validateGrade();
    if (!isValidInput) return;

    // compute Mean of grades
    let value = 0;
    let count = 0;
    const list = document.getElementsByClassName('activities');
    Array.prototype.forEach.call(list, function(e) {
      const grade1 = e.querySelector('#grade1');
      const grade2 = e.querySelector('#grade2');
      const val = parseInt(grade1.value)/parseInt(grade2.value);
      value = value + val;
      count++;
    })
    computedResult.innerHTML = value/count;
  })

  const validateInputValue = function() {
    const list = document.getElementsByClassName('activities');
    let isValid = true;
    Array.prototype.forEach.call(list, function(e) {
      const grade1 = e.querySelector('#grade1');
      const grade2 = e.querySelector('#grade2');
      const weight = e.querySelector('#weight');
      grade1.classList.remove('error');
      grade2.classList.remove('error');
      weight.classList.remove('error');

      if (!grade1.value) {
        grade1.classList.add('error');
        isValid = false;
      }
      if (!grade2.value) {
        grade2.classList.add('error');
        isValid = false;
      }
      if (!weight.value) {
        weight.classList.add('error');
        isValid = false;
      }
    })
    return isValid;
  }

  const validateGrade = function() {
    const list = document.getElementsByClassName('activities');
    let isValid = true;
    Array.prototype.forEach.call(list, function(e) {
      const grade1 = e.querySelector('#grade1');
      const grade2 = e.querySelector('#grade2');
      const weight = e.querySelector('#weight');
      grade1.classList.remove('error');
      grade2.classList.remove('error');
      weight.classList.remove('error');

      if (!grade1.value) {
        grade1.classList.add('error');
        isValid = false;
      }
      if (!grade2.value) {
        grade2.classList.add('error');
        isValid = false;
      }
    })
    return isValid;
  }

  const computedPercent = function() {
    Array.prototype.forEach.call(row, function(e) {
      const grade1 = e.querySelector('#grade1');
      const grade2 = e.querySelector('#grade2');
      const percent = e.querySelector('#percent');
      grade1.oninput = function(e) {
        if (grade1.value && grade2.value) {
          percent.innerHTML = parseInt(grade1.value)/parseInt(grade2.value);
        } else {
          percent.innerHTML = ''
        }
      }
      grade2.oninput = function(e) {
        if (grade1.value && grade2.value) {
          percent.innerHTML = parseInt(grade1.value)/parseInt(grade2.value);
        } else {
          percent.innerHTML = ''
        }
      }
    })
  }

  computedPercent();
  
}
